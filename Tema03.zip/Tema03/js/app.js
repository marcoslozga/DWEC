function ejercicio1() {
    const edad = 20;
    const nombre = "Marcos";
    const esEstudiante = true;
    const coche = null;
    let telefono;
    const poblacionMundial = 8000000000n;

    let asignatura;
    asignatura = "Desarrollo Web en Entornos Cliente";

    console.log("--- Ejercicio 1: Variables y typeof ---");
    console.log("edad:", edad, "-> typeof:", typeof edad);
    console.log("nombre:", nombre, "-> typeof:", typeof nombre);
    console.log("esEstudiante:", esEstudiante, "-> typeof:", typeof esEstudiante);
    console.log("coche:", coche, "-> typeof:", typeof coche);
    console.log("telefono:", telefono, "-> typeof:", typeof telefono);
    console.log("poblacionMundial:", poblacionMundial, "-> typeof:", typeof poblacionMundial);
    console.log("asignatura:", asignatura, "-> typeof:", typeof asignatura);
}

function ejercicio2() {
    console.log("--- Ejercicio 2: Conversiones explícitas ---");

    const c1 = String(123);
    console.log(c1, typeof c1);

    const c2 = Number("123");
    console.log(c2, typeof c2);

    const c3 = Number("12abc");
    console.log(c3, typeof c3);

    const c4 = Number("");
    console.log(c4, typeof c4);

    const c5 = Number(true);
    console.log(c5, typeof c5);

    const c6 = Boolean(0);
    console.log(c6, typeof c6);

    const c7 = Boolean("texto");
    console.log(c7, typeof c7);

    const c8 = Boolean("");
    console.log(c8, typeof c8);
}

function ejercicio3() {
    console.log("--- Ejercicio 3: Coerción y comparaciones ---");

    console.log('"5" - 2 =', "5" - 2);
    console.log('"5" + 2 =', "5" + 2);
    console.log('"10" * "2" =', "10" * "2");
    console.log('true + 1 =', true + 1);
    console.log('"Hola" + 5 =', "Hola" + 5);
    console.log('"20" / "4" =', "20" / "4");

    console.log('5 == "5":', 5 == "5");
    console.log('5 === "5":', 5 === "5");
    console.log('0 == false:', 0 == false);
    console.log('0 === false:', 0 === false);
    console.log('null == undefined:', null == undefined);
    console.log('null === undefined:', null === undefined);
}

function ejercicio4() {
    const nombreFicha = "Marcos";
    const ciclo = "Desarrollo de Aplicaciones Web";
    const curso = "2026/2027";
    const aficion = "Programación y videojuegos";
    
    let horasEstudio = 5;
    horasEstudio += 3;

    const mensajeTemplate = `Alumno: ${nombreFicha}, Ciclo: ${ciclo}, Curso: ${curso}, Afición: ${aficion}, Horas de estudio: ${horasEstudio}`;
    alert(mensajeTemplate);
    console.log("Template string:", mensajeTemplate);

    const mensajeConcat = "Alumno: " + nombreFicha + ", Ciclo: " + ciclo + ", Curso: " + curso + ", Afición: " + aficion + ", Horas de estudio: " + horasEstudio;
    console.log("Concatenación (+):", mensajeConcat);

    console.log("¿Son estrictamente iguales?:", mensajeTemplate === mensajeConcat);
}